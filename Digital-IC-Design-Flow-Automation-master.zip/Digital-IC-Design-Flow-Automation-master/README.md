# Digital-IC-Design-Flow-Automation
This repository contains script files for the Digital IC Automation tool

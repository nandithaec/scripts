# python2 version of gui code

from Tkinter import *
import Tkinter, Tkconstants, tkFileDialog
import tkMessageBox
import csv
import os

# Functions to act on an event caused by user interaction

def about():
    tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Developed under the guidance of Prof. Nanditha Rao at IIITB")

def design_nameinput_enter(event):
    if (len(design_name.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a Design name")

def outputpath_enter(event):
	if (len(outputpath.get())==0):
		tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Output Path")

def outputpath_browse():
    directory = tkFileDialog.askdirectory()
    outputpath.insert(0,directory)	

def librarypath_enter(event):
    if (len(librarypath.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Library Path")

def librarypath_browse():
    directory = tkFileDialog.askdirectory()
    librarypath.insert(0,directory)

def netlistpath_enter(event):
    if (len(netlistpath.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Netlist Path")

def netlistpath_browse():
    directory = tkFileDialog.askdirectory()
    netlistpath.insert(0,directory)

def earlylibrarypath_enter(event):
    if (len(earlylibrarypath.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Early Library Path")

def earlylibrarypath_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("lib files","*.lib"),("all files","*.*")))
    earlylibrarypath.insert(0,filepath)

def latelibrarypath_enter(event):
    if (len(latelibrarypath.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Late Library Path")

def latelibrarypath_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("lib files","*.lib"),("all files","*.*")))
    latelibrarypath.insert(0,filepath)

def constraintsfile_enter(event):
    if (len(constraintsfile.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Constraints File")

def constraintsfile_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("csv files","*.csv"),("all files","*.*")))
    constraintsfile.insert(0,filepath)

def Captable_enter(event):
    if (len(Captable.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Captable File")

def Captablefile_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("capTbl files","*.capTbl"),("all files","*.*")))
    Captable.insert(0,filepath)

def QRC_Tech_enter(event):
    if (len(QRC_Tech.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid QRC_Tech File")

def QRC_Techfile_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("tch files","*.tch"),("all files","*.*")))
    QRC_Tech.insert(0,filepath)

def Technology_LEF_enter(event):
    if (len(Technology_LEF.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Technology LEF File")

def Technology_LEF_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("lef files","*.lef"),("all files","*.*")))
    Technology_LEF.insert(0,filepath)

def Macro_LEF_enter(event):
    if (len(Macro_LEF.get())==0):
        tkMessageBox.showinfo("Digital IC Design Flow Automation Tool", "Please Enter a valid Macro LEF File")

def Macro_LEF_browse():
    filepath = tkFileDialog.askopenfilename(title = "Select file", filetypes = (("lef files","*.lef"),("all files","*.*")))
    Macro_LEF.insert(0,filepath)

def runscript():
    designName=design_name.get()
    designNameFile=open(designName+"_details.csv", "w")
    design_details_file=csv.writer(designNameFile, delimiter=',')
    design_details_file.writerow(['Design Name',designName])
    design_details_file.writerow(['Output Directory',outputpath.get()])
    design_details_file.writerow(['Library Path',librarypath.get()])
    design_details_file.writerow(['Netlist Directory',netlistpath.get()])
    design_details_file.writerow(['Early Library Path',earlylibrarypath.get()])
    design_details_file.writerow(['Late Library Path',latelibrarypath.get()])
    design_details_file.writerow(['Constraints File',constraintsfile.get()])
    design_details_file.writerow(['Captable',Captable.get()])
    design_details_file.writerow(['QRC_Tech',QRC_Tech.get()])
    design_details_file.writerow(['Technology LEF',Technology_LEF.get()])
    design_details_file.writerow(['Macro LEF',Macro_LEF.get()])
    designNameFile.close()
    arg = designName + "_details.csv"
    # print(arg)
    synthesis = "tclsh synthesis_pnr.tcl " + arg	
    os.system('%s' %synthesis)	
    # subprocess.call(["./cad.csh", (outputpath.get()+"/"+designName+".tcl")])

# GUI code

root = Tk()

root.title("Digital IC Design Flow Automation Tool")

root.geometry("650x650")

Label(root, text="Digital IC Design Flow Automation", font='Helvetica 18 bold', pady=10).grid(row=0,column=1)

# Menu bar

menubar = Menu(root)
options = Menu(menubar, tearoff=0)
options.add_separator()
options.add_command(label="Exit", command=root.quit)
menubar.add_cascade(label="Options", menu=options)
 
helpmenu = Menu(menubar, tearoff=0)
helpmenu.add_command(label="About...", command=about)
menubar.add_cascade(label="Help", menu=helpmenu)

# Design name

Label(root, text="Design name: ", font='Helvetica 10 bold', padx=10).grid(row=1, pady=10)
design_name = Entry(root)
design_name.grid(row=1, column=1)
design_name.bind("<Return>", design_nameinput_enter)

# Output Directory

Label(root, text="Output path: ", font='Helvetica 10 bold', padx=10).grid(row=2, pady=10)
outputpath = Entry(root)
outputpath.grid(row=2, column=1)
outputpath.bind("<Return>", outputpath_enter)

browsebutton = Button(root, text="Browse", command=outputpath_browse)
browsebutton.grid(row=2,column=2)

# Library Path

Label(root, text="Library Path: ", font='Helvetica 10 bold', padx=10).grid(row=3, pady=10)
librarypath = Entry(root)
librarypath.grid(row=3, column=1)
librarypath.bind("<Return>", librarypath_enter)

browsebutton = Button(root, text="Browse", command=librarypath_browse)
browsebutton.grid(row=3,column=2)

# Netlist Directory

Label(root, text="Netlist path: ", font='Helvetica 10 bold', padx=10).grid(row=4, pady=10)
netlistpath = Entry(root)
netlistpath.grid(row=4, column=1)
netlistpath.bind("<Return>", netlistpath_enter)

browsebutton = Button(root, text="Browse", command=netlistpath_browse)
browsebutton.grid(row=4,column=2)

# Early Library Path

Label(root, text="Early Library path: ", font='Helvetica 10 bold', padx=10).grid(row=5, pady=10)
earlylibrarypath = Entry(root)
earlylibrarypath.grid(row=5, column=1)
earlylibrarypath.bind("<Return>", earlylibrarypath_enter)

browsebutton = Button(root, text="Browse", command=earlylibrarypath_browse)
browsebutton.grid(row=5,column=2)

# Late Library Path

Label(root, text="Late Library path: ", font='Helvetica 10 bold', padx=10).grid(row=6, pady=10)
latelibrarypath = Entry(root)
latelibrarypath.grid(row=6, column=1)
latelibrarypath.bind("<Return>", latelibrarypath_enter)

browsebutton = Button(root, text="Browse", command=latelibrarypath_browse)
browsebutton.grid(row=6,column=2)

# Constraints File

Label(root, text="Constraints File: ", font='Helvetica 10 bold', padx=10).grid(row=7, pady=10)
constraintsfile = Entry(root)
constraintsfile.grid(row=7, column=1)
constraintsfile.bind("<Return>", constraintsfile_enter)

browsebutton = Button(root, text="Browse", command=constraintsfile_browse)
browsebutton.grid(row=7,column=2)

# Captable

Label(root, text="Captable: ", font='Helvetica 10 bold', padx=10).grid(row=8, pady=10)
Captable = Entry(root)
Captable.grid(row=8, column=1)
Captable.bind("<Return>", Captable_enter)

browsebutton = Button(root, text="Browse", command=Captablefile_browse)
browsebutton.grid(row=8,column=2)

# QRC_Tech

Label(root, text="QRC_Tech: ", font='Helvetica 10 bold', padx=10).grid(row=9, pady=10)
QRC_Tech = Entry(root)
QRC_Tech.grid(row=9, column=1)
QRC_Tech.bind("<Return>", QRC_Tech_enter)

browsebutton = Button(root, text="Browse", command=QRC_Techfile_browse)
browsebutton.grid(row=9,column=2)

# Technology LEF

Label(root, text="Technology LEF: ", font='Helvetica 10 bold', padx=10).grid(row=10, pady=10)
Technology_LEF = Entry(root)
Technology_LEF.grid(row=10, column=1)
Technology_LEF.bind("<Return>", Technology_LEF_enter)

browsebutton = Button(root, text="Browse", command=Technology_LEF_browse)
browsebutton.grid(row=10,column=2)

# Macro LEF

Label(root, text="Macro LEF: ", font='Helvetica 10 bold', padx=10).grid(row=11, pady=10)
Macro_LEF = Entry(root)
Macro_LEF.grid(row=11, column=1)
Macro_LEF.bind("<Return>", Macro_LEF_enter)

browsebutton = Button(root, text="Browse", command=Macro_LEF_browse)
browsebutton.grid(row=11,column=2)

# Ok

b_final = Button(root, text="OK", padx=10, command=runscript)
b_final.grid(row=12, column=1)
 
# starting the gui

root.config(menu=menubar)
root.mainloop()
